package xyz.rfz.ir;

import android.app.*;
import android.os.*;
import android.hardware.*;
import android.content.*;
import android.widget.*;
import android.view.*;
import android.webkit.*;
import androidx.core.*;
import androidx.core.app.*;
import android.*;
import android.content.pm.*;
import java.nio.file.*;
import java.io.*;

public class MainActivity extends Activity 
{
	WebView browser;
	
	
	public class WebAppInterface{
		Context mContext;
	
	WebAppInterface(Context c){
		mContext=c;
	}
	
	@JavascriptInterface
	public void send(int f, int[] t){
		
		ConsumerIrManager cim=(ConsumerIrManager)getApplicationContext().getSystemService(Context.CONSUMER_IR_SERVICE);
		boolean iftt=cim.hasIrEmitter();
		if(!iftt){
			Toast.makeText(mContext,"there is no ir transmitter",Toast.LENGTH_SHORT).show();

		}
		else{
			cim.transmit(f,t);
			//Toast.makeText(mContext,"transmitted",Toast.LENGTH_SHORT).show();
			Vibrator v=(Vibrator)getSystemService(Context.VIBRATOR_SERVICE);
			v.vibrate(20);
		}
		}
	
	}
	
	
	

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		//asking permission
	
		ActivityCompat.requestPermissions(MainActivity.this,
										  new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
										  1);
		
		
		
		
		browser=(WebView)findViewById(R.id.webkit);
		browser.getSettings().setJavaScriptEnabled(true);
		
		browser.getSettings().setDomStorageEnabled(true);
		browser.clearCache(true);
		browser.addJavascriptInterface(new WebAppInterface(this), "ir");
		browser.getSettings().setBuiltInZoomControls(true);
		browser.getSettings().setDisplayZoomControls(false);
		browser.setWebViewClient(new WebViewClient()
		{ 
		@Override
		public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) { loadErrorPage(view, description,failingUrl, errorCode); }
		});}
	public void loadErrorPage(WebView webview,String description, String failingUrl, int errorCode ){
        if(webview!=null){

            String htmlData ="<html><body><div align=\"center\" >This is the description for the load fail : "+description+"<br>error code: "+errorCode+"<br>The failed url is : "+failingUrl+"<br></div></body>";

            webview.loadUrl("about:blank");
           webview.loadDataWithBaseURL(null,htmlData, "text/html", "UTF-8",null);
            webview.invalidate();

        }
    }
		
		//o
		
	

	@Override
	public void onRequestPermissionsResult(int requestCode,
										   String permissions[], int[] grantResults) {
		switch (requestCode) {
			case 1: {

					// If request is cancelled, the result arrays are empty.
					if (grantResults.length > 0
						&& grantResults[0] == PackageManager.PERMISSION_GRANTED) {

						// permission was granted, yay! Do the
						   /*
						File direct = new File(Environment.getExternalStorageDirectory()+"/rafiz");
						alert(Environment.getExternalStorageDirectory());
						if(!direct.exists()) {
							if(direct.mkdir()); //directory is created;
						}
	*/
						
						browser.loadUrl("file:///storage/emulated/0/rafiz/index.html");
						
					} else {

						// permission denied, boo! Disable the
						// functionality that depends on this permission.
						Toast.makeText(MainActivity.this, "Permission denied to read your External storage", Toast.LENGTH_SHORT).show();
					}
					return;
				}

				// other 'case' lines to check for other
				// permissions this app might request
		}
	}
	
	
	

	


	
    @Override
	public boolean onKeyDown(int keyCode, KeyEvent event){
		if((keyCode==KeyEvent.KEYCODE_BACK)&&browser.canGoBack()){
			browser.goBack(); 
			//Toast.makeText(getApplicationContext(),"S",Toast.LENGTH_SHORT).show();
			return true;}
        return super.onKeyDown(keyCode, event);
	}

}